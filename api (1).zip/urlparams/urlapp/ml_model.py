#!/usr/bin/env python
# coding: utf-8

# In[1]:


#load dataset 
import pandas as pd
df = pd.read_csv('data/get_dataset.csv')


# In[2]:


import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from urllib.parse import urlparse
import requests

# Load the dataset

# Separate features (X) and labels (y)
X = df.drop(['url','status'], axis=1) 
y = df['status'] 


# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Number of features in X_train: {X_train.shape[1]}")
print(f"Number of features in X_test: {X_test.shape[1]}")
# Initialize the Random Forest classifier
clf = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the classifier
clf.fit(X_train, y_train)

# Make predictions on the test set
y_pred = clf.predict(X_test)
# print(X_test.head)
# print(y_pred)
# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy}")


# In[4]:


import re
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin
from urllib.parse import urlparse
import aiohttp
from datetime import datetime
import whois
from urllib.parse import urlparse
import dns.resolver
import aiohttp
import asyncio
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import pandas as pd
import requests
import re

# Function to extract the length of the URL
def check_url_length(url):
        url_length = len(url)
        return url_length # Example phishing detection logic

def host_name_length(url):
    # Extract the hostname from the URL
    hostname = urlparse(url).hostname 
    # Check if the length of the hostname exceeds 30 characters
    return len(hostname)
    
def nb_dots(url, nb_dots_threshold=3):
    parsed_url = urlparse(url)
    path = parsed_url.netloc  # Get the network location part of the URL
    nb_dots = path.count('.')
    return nb_dots 


def count_hyphens(url):
    parsed_url = urlparse(url)
    domain = parsed_url.netloc
    hyphen_count = domain.count("-")
    return hyphen_count 
    

def at_symbol(url):
    try:
        response = requests.get(url)
        html_content = response.text
        if "@" in html_content:
            return 1  # Phishing detected
        else:
            return 0  # No phishing detected
    except Exception as e:
        # print("Error:", e)
        return -1  # Error occurred
        
def ip_address_presence(url):
    # Extract the hostname from the URL
    hostname = urlparse(url).hostname
    
    # Check if the hostname contains an IP address
    ip_present = re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', hostname)
    
    # Return 1 if phishing is detected (IP address present), otherwise 0
    return (1 if ip_present else 0)

def underscore(url):
    parsed_url = urlparse(url)
    if '_' in parsed_url.path:
        return 1  # Phishing attempt detected
    return 0  # No phishing detected

from urllib.parse import urlparse, parse_qs
def tild(url):
    try:
        response = requests.get(url)
        if response.status_code == 200:
            parsed_url = urlparse(url)
            query_params = parse_qs(parsed_url.query)
            if 'tilde_in' in query_params:
                return 1  # Phishing detected
            else:
                return 0  # Not phishing
        else:
            return -1  # URL couldn't be accessed
    except Exception as e:
        # print("Error:", e)
        return -1

# Function to check the presence of a prefix or suffix in the domain
def prefix_suffix_presence(url):
    # Extract the domain part from the URL
    domain_match = re.search(r'https?://([^/]+)', url)
    if domain_match:
        domain = domain_match.group(1)
        # Check if the domain starts or ends with a prefix or suffix
        if domain.startswith('-') or domain.endswith('-'):
            return 1  # Phishing
        else:
            return 0  # Legitimate
    else:
        return -1  # Invalid URL

# Function to check the presence of a random domain
def random_domain_presence(url):
    # Extract the domain part from the URL
    domain_match = re.search(r'https?://([^/]+)', url)
    if domain_match:
        domain = domain_match.group(1)
        # Check if the domain contains a random string
        if domain.count('-') >= 3:
            return 1  # Phishing
        else:
            return 0  # Legitimate
    else:
        return -1  # Invalid URL

# Function to extract the path extension
def path_extension(url):
    # Parse the URL and extract the path
    parsed_url = urlparse(url)
    path = parsed_url.path
    # Check if the path has an extension
    if '.' in path:
        return 1  # Phishing
    else:
        return 0  # Legitimate

# Function to check the presence of HTTP in the domain
def http_in_domain(url):
    # Extract the domain part from the URL
    domain_match = re.search(r'https?://([^/]+)', url)
    if domain_match:
        domain = domain_match.group(1)
        # Check if the domain contains "http"
        if "http" in domain:
            return 1  # Phishing
        else:
            return 0  # Legitimate
    else:
        return -1  # Invalid URL
        
def shorting_services(url):
    # Regular expression pattern to match known shortening services
    shortening_service_pattern = r'^https?://(bit\.ly|goo\.gl|t\.co|tinyurl\.com|ow\.ly|cl\.ly)'
    
    # Check if the URL matches the shortening service pattern
    shortening_service = bool(re.match(shortening_service_pattern, url))
    
    # If shortening service detected, flag as potential phishing
    if shortening_service:
        return 1
    else:
        return 0
def port(url):
    try:
        parsed_url = urlparse(url)
        
        # Check if port is present
        port = parsed_url.port
        port_phish = 1 if port else 0
        
        # Additional checks if needed
        
        # Logic to determine if it's a phishing site
        if port_phish == 1:
            return 1
        else:
            return 0
            
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred
def check_domain_brand(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        parsed_url = urlparse(url)
        domain_in_brand = bool(re.search(r'(google|facebook|twitter)', parsed_url.hostname))
        domain_in_brand_phish = 1 if domain_in_brand else 0
        
        return domain_in_brand_phish
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred

# Function to check the presence of SFH (Server Form Handler)
def check_sfh(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # SFH detection
        sfh = bool(re.search(r'<form\s+action\s*=\s*["\']mailto:', response.text))
        
        if sfh in url:
            return 1  # Phishing site
        else:
            return 0  # Not a phishing site
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred

def check_iframe(url):
    try:
        iframe = bool(re.search(r'<iframe\s+', requests.get(url).text))
        return 1 if iframe else 0
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred
# Function to check the presence of iframe


# Function to check the presence of pop-up window
def pop_up_window(url):
    try:
        # Presence of pop-up window
        pop_up_window = bool(re.search(r'window\.open', requests.get(url).text))
        pop_up_window_phish = 1 if pop_up_window else 0 # Example phishing detection logic
        
        return pop_up_window_phish
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred
        
def right_click(url):
    try:
        # Fetch the HTML content of the webpage
        response = requests.get(url)
        html_content = response.text
        
        # Presence of right click disable
        right_click_disable = bool(re.search(r'oncontextmenu\s*=\s*["\']return\s*false["\']', html_content))
        
        # Example phishing detection logic
        phishing_prediction = 1 if right_click_disable else 0
        
        return phishing_prediction

    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred  


def check_onmouseover_phishing(url):
    try:
        # Fetching HTML content of the URL
        response = requests.get(url)
        html_content = response.text
        
        # Checking for presence of 'onmouseover' attribute
        onmouseover = bool(re.search(r'onmouseover\s*=', html_content))
        
        # Phishing detection logic
        if onmouseover:
            return 1  # Phishing site
        else:
            return 0  # Not a phishing site
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred
        
def detect_copyright(url):
    try:
        # Fetch the content of the URL
        response = requests.get(url)
        if response.status_code != 200:
            # print(f"Failed to fetch {url}. Status code: {response.status_code}")
            return -1  # Unable to fetch the URL

        # Check if the copyright symbol is present in the content
        domain_with_copyright = bool(re.search(r'©', response.text))

        # Example phishing detection logic
        if domain_with_copyright:
            return 1  # Phishing detected
        else:
            return 0  # No phishing detected
    except Exception as e:
        # print("Error:", e)
        return -1  # Some error occurred during the process

# Function to calculate domain age
import whois
from datetime import datetime

def get_domain_age(domain_name):
    try:
        # Query WHOIS information for the domain
        domain_info = whois.whois(domain_name)

        # Extract the creation date from the WHOIS record
        creation_date = domain_info.creation_date

        # Check if the creation_date is a list (some domains may have multiple creation dates)
        if isinstance(creation_date, list):
            creation_date = min(creation_date)  # Choose the earliest creation date

        # Calculate the domain age
        if creation_date:
            current_date = datetime.now()
            age = (current_date - creation_date).days
            return age
        # else:
        #     return "Creation date not found in WHOIS record."
    except Exception as e:
        return -1


# Function to calculate domain registration length
async def check_for_key_words(url):
    phishing_keywords = [
      'urgent', 'immediate action required', 'security alert', 'update your information',
        'unusual activity', 'account suspension', 'click here', 'free', 'pay now',
        'phish', 'scam', 'fraud', 'urgent', 'emergency', 'fake', 'warning', 'alert', 'beware', 'unauthorized'
   'Free','Click here to claim your prize','Special offer','Limited time offer','Discount','Sale','Exclusive deal'
    ]
    try:
        # Check if URL is absolute
        if not bool(urlparse(url).netloc):
            raise ValueError("URL should be absolute")

        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60)) as session:  # Set a timeout of 60 seconds
            async with session.get(url) as response:
                response.raise_for_status()
                html_content = await response.text(encoding='ISO-8859-1')

                # Load HTML content into BeautifulSoup
                soup = BeautifulSoup(html_content, 'html.parser')

                # Extract text from HTML elements
                website_text = soup.get_text().lower()

                # Check for phishing keywords
                detected_keywords = [keyword for keyword in phishing_keywords if keyword in website_text]

                return 1 if detected_keywords else 0

    except (aiohttp.ClientError, ValueError) as error:
        # print(f"Error: {error}")
        return -1

async def process_urls(urls):
    results = []
    for url in urls:
        try:
            result = await check_for_key_words(url)
            results.append(result)
        except asyncio.TimeoutError:
            print(f"Timeout occurred for URL: {url}. Moving to the next URL.")
            results.append(-1)  # Assigning a default value (-1) for failed URLs
    return results
    
async def predict_phishing(url):
    # Extracting features
    url_features = {
        'url_length': check_url_length(url),
        'hostname_length': host_name_length(url),
        'ip': ip_address_presence(url),
        'dots': nb_dots(url),
        'at_symbol': at_symbol(url),
        'hyphen': count_hyphens(url),
        'underscore': underscore(url),
        'tild': tild(url),
        # 'under_score': underscore_count(url),
        'prefix': prefix_suffix_presence(url),
        'random_domain': random_domain_presence(url),
        'sort_service': shorting_services(url),
        'path_extension': path_extension(url),
        'http_in_domain': http_in_domain(url),
        'port': port(url),
        'check_domain': check_domain_brand(url),
        'sfh': check_sfh(url),
        'check_iframe': check_iframe(url),
        'pop_up': pop_up_window(url),
        'right_click': right_click(url),
        'over_mouse': check_onmouseover_phishing(url),
        'copy_right': detect_copyright(url),            
        'domain_age': get_domain_age(url),
        # 'web_traffic': web_traffic(url),
        'key_words': await check_for_key_words(url)
    }

    # Placeholder for remaining features
    # You can implement the remaining feature extraction logic here
    # Make the prediction using the extracted features
    print("FEATURES: ", url_features)

    url_params = [url_features[feature] for feature in url_features]  # Example values
    # print(url_params['domain_age'])
    # Placeholder prediction, replace with your actual prediction logic
    prediction = clf.predict([url_params])

    if url_features['url_length'] > 56:
        url_features['url_length'] = 1
    url_features['url_length'] = 0

    if url_features['hostname_length'] > 30:
        url_features['hostname_length'] = 1
    url_features['hostname_length'] = 0

    if url_features['domain_age'] < 366:
        url_features['domain_age'] = 1
    url_features['domain_age'] = 0

    url_params = [url_features[feature] for feature in url_features]
    total_count = len(url_params)

    phishing_count = url_params.count(1)
    legitimate_count = url_params.count(0)
    phishing_or_legitimate = url_params.count(-1)

    phishing_or_legitimate_percentage = (phishing_or_legitimate / total_count) * 100
    # print(prediction)
    
    # Map the prediction to 'phishing' or 'legitimate'
    result = 1 if prediction=='phishing' else 0

    if result == 1:
        phishing_perceantage = ((phishing_count/total_count) * 100) + phishing_or_legitimate_percentage
        legitimate_perceantage = (legitimate_count/total_count) * 100
    else:   
        phishing_perceantage = (phishing_count/total_count) * 100
        legitimate_perceantage = ((legitimate_count/total_count) * 100) + phishing_or_legitimate_percentage
    
    return [result, url_features, round(phishing_perceantage, 2), round(legitimate_perceantage, 2)]