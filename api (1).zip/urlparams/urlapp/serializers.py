# from rest_framework import serializers
# from .models import URLPrediction
# from .ml_model import predict_phishing

# class URLPredictionSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = URLPrediction
#         fields = ['url', 'predicted']

#     def create(self, validated_data):
#         url = validated_data['url']
#         predicted = predict_phishing(url)
#         instance = URLPrediction.objects.create(url=url, predicted=predicted)
#         return instance
import asyncio
from rest_framework import serializers
from .models import CheckURL
from .ml_model import predict_phishing
class UrlSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = CheckURL
        fields = ['id', 'url', 'prediction','Parameter', 'phishing', 'legitimate']
        read_only_fields = ['prediction','Parameter', 'phishing', 'legitimate']
    def create(self, validated_data):
        url = validated_data['url']
        prediction = asyncio.run(predict_phishing(url))
        instance = CheckURL.objects.create(url=url, prediction=prediction[0],Parameter=prediction[1], phishing = prediction[2], legitimate = prediction[3])
        return instance

