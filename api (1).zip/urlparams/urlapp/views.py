import asyncio
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import generics
from .models import CheckURL
from django.shortcuts import render


# views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
 # Assuming you have a function to predict phishing
# from .models import URLPrediction  # Assuming you have a model to store predictions
from rest_framework import viewsets
from rest_framework.response import Response
from .ml_model import predict_phishing
import csv
from .serializers import UrlSerializer


# API view to report issues with the Gateway Meet
class URLCheckViewSet(APIView):
    def post(self, request):
        # Assuming the report is passed as a JSON object in the request body
        try:
            url = request.data.get('url')
            if url:
                 is_phishing = asyncio.run(predict_phishing(url))
                 with open('phishing_results.csv', 'a') as csvfile:
                     writer = csv.writer(csvfile)
                     writer.writerow([url, is_phishing])
                 return Response({'url': url, 'is_phishing': is_phishing})
            else:
                 return Response({'error': 'URL parameter is missing'})
        except Exception as e:
             print("Something went wrong", e)
             return Response(data={'message': 'Something went wrong!!'}, status=500)
        
        


class URLCheckViewsset(viewsets.ModelViewSet):
    queryset=CheckURL.objects.all()
    serializer_class=UrlSerializer

def home(request):
    if request.method == 'POST':
        url = request.POST.get('sms_text', '')  # Assuming the textarea has name 'sms_text'
        print(url)
        prediction = asyncio.run(predict_phishing(url))
        print(prediction)
        return render(request, 'result.html', {'prediction': prediction[0], 'sms_text': url})
    
    return render(request, 'home.html')



