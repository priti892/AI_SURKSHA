from django.contrib import admin
from .models import CheckURL
# Register your models here.
admin.site.register(CheckURL)