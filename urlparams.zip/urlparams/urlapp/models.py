from django.db import models



class CheckURL(models.Model):
    url = models.URLField(max_length=200)
    prediction = models.CharField(max_length=20, null=True, blank=True)
    Parameter = models.CharField(max_length=100, default='default_value')
    phishing = models.FloatField(default=0.0)
    legitimate = models.FloatField(default=0.0)

    

#     def save(self, *args, **kwargs):
#         if self.pk is None:  # If the instance is being created
#             model = load_spam_detection_model(settings.SPAM_DETECTION_MODEL_PATH)
#             prediction = predict_spam(model, self.text)
#             self.is_spam = prediction

#         super().save(*args, **kwargs)

#     def __str__(self):
#         return self.text
