## Install the plugin

This requires you to turn on developer mode in chrome extensions. Navigate to `chrome://extensions/` and turn on developer mode.

1. You may consider using packed release version of this plugin. Download latest release from [here](https://github.com/picopalette/phishing-detection-plugin/releases) and ignore any warnings. Drag the downloaded `.crx` file into the `chrome://extensions/` page.

2. For unpacked versions, select **load unpacked** and choose the `frontend` directory of this repository.
