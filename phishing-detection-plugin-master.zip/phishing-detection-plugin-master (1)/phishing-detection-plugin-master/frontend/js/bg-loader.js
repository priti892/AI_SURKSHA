try {
  importScripts('randomforest.js', 'background.js');
} catch (e) {
  console.error(e);
}