// import { url } from "./features.js";
// import {url} from "./features"
// const url = window.location.href; 

var colors = {
    "-1": "#248056",
    "0": "#ff9f00",
    "1": "#d63847"
};
var featureList = document.getElementById("features");
var row1 = document.querySelector(".row1");
var row2 = document.querySelector(".row2");
var row3 = document.querySelector(".row3");
var row4 = document.querySelector(".row4");
var row5 = document.querySelector(".row5");
var row6 = document.querySelector(".row6");
var row7 = document.querySelector(".row7");

// Request URL
// Port
// IP Address
// iFrames
// @ Symbol
// (-) Prefix/Suffix in domain
// Tiny URL
// HTTPS
// HTTPS in URL's domain part
// Anchor
// URL Length
// No. of Sub Domains
// Script & Link
// mailto
// SFH
// Favicon
// Redirecting using //
// Path Extension
// Right Click
// Copyright
// Host
// Pop Up Window
// Shortning Services
// Keywords

var textMap = {
    "url_length": "URL Length",
    "ip": "IP Address",
    // "dots": 2,
    "at_symbol": "@ Symbol",
    // "hyphen": 0,
    // "underscore": 0,
    // "tild": 0,
    "prefix": "(-) Prefix/Suffix in domain",
    // "random_domain": 0,
    "http_in_domain": "HTTPS in URL's domain part",
    "port": "Port",
    // "check_domain": 0,
    "sfh": "SFH",
    "check_iframe": "iFrames",
    "path_extension": "Path Extension",
    "right_click": "Right Click",
    // "over_mouse": 0,
    "copy_right": "Copyright",
    "hostname_length": "Host",
    "pop_up": "Pop Up Window",
    "sort_service": "Shortening Services",
    // "domain_age": 5347,
    "key_words": "Keywords"
}

const desiredKeyOrder = [
    'dots',
    'hyphen',
    'underscore',
    'tild',
    'random_domain',
    'check_domain',
    'over_mouse',
    'domain_age',
    'port',
    'ip',
    'check_iframe',
    'at_symbol',
    'prefix',
    'http_in_domain',
    'url_length',
    'sfh',
    'path_extension',
    'right_click',
    'copy_right',
    'hostname_length',
    'pop_up',
    'sort_service',
    'key_words'
];

let prediction;
let phishingPercentage;
let legitimatePercent;

chrome.tabs.query({ currentWindow: true, active: true }, function (tabs) {

    fetch('http://127.0.0.1:8000/all/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            url: tabs[0].url
        }),
    })
        .then(async response => {
            var api_response = await response.json();
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }   
            prediction  = JSON.parse(api_response.prediction);
            var parameters = JSON.parse(api_response.Parameter.replace(/'/g, '"'));
            phishingPercentage  = Math.round(JSON.parse(api_response.phishing));
            legitimatePercent  = Math.round(JSON.parse(api_response.legitimate));

            
            // Reorder the keys according to the desired order
            const reorderedParameters = {};
            desiredKeyOrder.forEach(key => {
                if (parameters.hasOwnProperty(key)) {
                    reorderedParameters[key] = parameters[key];
                }
            });

            console.log(api_response, reorderedParameters, phishingPercentage, legitimatePercent);
            const keys = Object.keys(reorderedParameters).slice(8, 23);
            let count = 0;
            keys.forEach(key => {
                var newFeature = document.createElement("div");
                newFeature.textContent = textMap[key];
                newFeature.className = "rounded item";
                if (reorderedParameters[key] == 0) {
                    newFeature.style.border = `2px solid #248056`;
                    newFeature.style.boxShadow = `0 0 3px #248056`;
                }
                else if (reorderedParameters[key] == 1) {
                    newFeature.style.border = `2px solid #d63847`;
                    newFeature.style.boxShadow = `0 0 3px #d63847`;
                }
                else {
                    newFeature.style.border = `2px solid #ff9f00`;
                    newFeature.style.boxShadow = `0 0 3px #ff9f00`;
                }
                if (count < 3) {
                    count++;
                    row1.appendChild(newFeature);
                }
                else if (count == 3 | count == 4) {
                    count++;
                    row2.appendChild(newFeature);
                }
                else if (count == 5) {
                    count++;
                    row3.appendChild(newFeature);
                }
                else if (count == 6) {
                    count++;
                    row4.appendChild(newFeature);
                }
                else if (count == 7) {
                    count++;
                    row5.appendChild(newFeature);
                }
                else if (count > 7 & count < 12) {
                    count++;
                    row6.appendChild(newFeature);
                }
                else if (count > 11) {
                    count++;
                    row7.appendChild(newFeature);
                }
            });

            document.getElementById("site_score").textContent = parseInt(legitimatePercent) + "%";
            if (prediction == "0") {
                document.getElementById("site_score").textContent = parseInt(legitimatePercent) + "%";
                document.querySelector('.circle').setAttribute('stroke-dasharray', parseInt(legitimatePercent) + ', 100');
            } else {
                document.getElementById("site_score").textContent = parseInt(phishingPercentage) + "%";
                document.querySelector('.circle').setAttribute('stroke-dasharray', parseInt(phishingPercentage) + ', 100');
            }

            var content = document.querySelector('.my-class');
            console.log(content);
            var loading = document.querySelector(".loading");
            loading.style.display = 'none';
            content.style.display = 'block';

        })

    chrome.storage.local.get(['results', 'legitimatePercents', 'isPhish'], function (items) {
        var result = items.results[tabs[0].id];
        var isPhish = items.isPhish[tabs[0].id];
        var legitimatePercent = items.legitimatePercents[tabs[0].id];
        var featureOrder = [
            "Request URL",
            "Port",
            "IP Address",
            "iFrames",
            "@ Symbol",
            "(-) Prefix/Suffix in domain",
            "Tiny URL",
            "HTTPS",
            "HTTPS in URL's domain part",
            "Anchor",
            "URL Length",
            "No. of Sub Domains",
            "Script & Link",
            "mailto",
            "SFH",
            "Favicon",
            "Redirecting using //"
        ];
        var commonFeatures = ["Port", "IP Address", "iFrames", "@ Symbol", "(-) Prefix/Suffix in domain", "HTTPS in URL's domain part", "URL Length", "SFH"]
        featureOrder.forEach(function (key) {
            if (result.hasOwnProperty(key)) {
                var newFeature = document.createElement("div");
                newFeature.textContent = key;
                newFeature.className = "rounded item";
                newFeature.style.border = `2px solid ${colors[result[key]]}`;
                newFeature.style.boxShadow = `0 0 3px ${colors[result[key]]}`;
                if (!commonFeatures.includes(key)){
                    if (featureOrder.indexOf(key) < 4) {
                        row1.appendChild(newFeature);
                    } else if (featureOrder.indexOf(key) < 7) {
                        row2.appendChild(newFeature);
                    } else if (featureOrder.indexOf(key) < 10) {
                        row3.appendChild(newFeature);
                    } else if (featureOrder.indexOf(key) < 13) {
                        row4.appendChild(newFeature);
                    } else {
                        row5.appendChild(newFeature);
                    }
                }                
            }
        });

        // var phishingPercentage = 100 - parseInt(legitimatePercent);
        // console.log("Phishing Percentage: " + phishingPercentage + "%");

        // $("#site_score").text(parseInt(legitimatePercent) + "%");
        // if (prediction == 0) {
        //     $("#res-circle").css("background", "#ff8b66");
        //     $("#site_msg").text("Warning!! You're being phished.");
        //     $("#site_score").text(parseInt(legitimatePercent)+ "%");
        //     document.querySelector('.circle').setAttribute('stroke-dasharray', parseInt(legitimatePercent) + ', 100');
        // }
        // else{
        //     $("#site_score").text(parseInt(phishingPercentage)+ "%");
        //     document.querySelector('.circle').setAttribute('stroke-dasharray', parseInt(phishingPercentage) + ', 100');
        // }
    });
});